

# Themas de VSCode

No hay mucho que decir, pueda que te gusten, pueda que no.

* [Aura Theme](https://marketplace.visualstudio.com/items?itemName=DaltonMenezes.aura-theme)

* [Monokai Night](https://marketplace.visualstudio.com/items?itemName=fabiospampinato.vscode-monokai-night)

* [Tokyo night](https://marketplace.visualstudio.com/items?itemName=enkia.tokyo-night)


