//*
//*    Objetivo:
//*        Jugar con la tabulación
//*
//*    Tips:
//*        Tab
//*        Tab + Shift
//*


const parrafo1 = `
                Hola!
Qué tal están?
            Todo bien
                    Saludos
    De nuevo
`;



//! Objetivo final !//
const parrafo2 = `
Hola!
    Qué tal están?
        Todo bien
        Saludos
De nuevo
`;

