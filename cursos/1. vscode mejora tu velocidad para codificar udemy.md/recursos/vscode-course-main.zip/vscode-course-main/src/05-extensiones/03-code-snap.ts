

// CodeSnap

class Temporal {

    constructor(parameters) {
        
    }
}


class OtraClase {
    constructor(parameters) {
        
    }
}
