






//! Ejemplo final - Tarea Snippet - c-class

class Hero {

    constructor() {
        console.log('Hero initialized');
    }

    showHero() {
        return this;
    }
} 





